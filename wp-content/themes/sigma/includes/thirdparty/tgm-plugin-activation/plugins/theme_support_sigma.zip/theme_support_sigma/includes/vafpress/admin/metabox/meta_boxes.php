<?php
$options = array();
$options[] = array(
	'id'          => '_bunch_layout_settings',
	'types'       => array('post', 'page', 'product', 'bunch_services', ),
	'title'       => __('Layout Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', BUNCH_NAME),
						'description' => __('Choose the layout for blog pages', BUNCH_NAME),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png',
							),
						),
					),
					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', BUNCH_NAME),
						'default' => '',
						'items' => bunch_get_sidebars(true)	
					),
				),
);
$options[] = array(
	'id'          => '_bunch_header_settings',
	'types'       => array('page', 'post', 'bunch_gallery'),
	'title'       => __('Header Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
					array(
						'type' => 'radioimage',
						'name' => 'header_style',
						'label' => __( 'Choose Header Style', BUNCH_NAME ),
						'item_max_height' => '200',
						'item_max_width' => '570',
						'items' => array(
							array(
								'value' => 'header_v1',
								'label' => __( 'Header Style One', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/header/header1.png' 
							),
							array(
								'value' => 'header_v2',
								'label' => __( 'Header Style Two', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/header/header2.png' 
							),
							array(
								'value' => 'header_v3',
								'label' => __( 'Header Style Three', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/header/header3.png' 
							),
							array(
								'value' => 'header_v4',
								'label' => __( 'Header Style Four', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/header/header4.png' 
							),
							array(
								'value' => 'header_v5',
								'label' => __( 'Header Style Five', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/header/header5.png' 
							),
							array(
								'value' => 'header_v6',
								'label' => __( 'Header Style Six', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/header/header6.png' 
							),
						),
						'default' => 'header_v1'
					),
					array(
						'type' => 'textbox',
						'name' => 'header_title',
						'label' => __('Header Title', BUNCH_NAME),
						'description' => __('Enter the Header title', BUNCH_NAME),
					),
					array(
						'type' => 'toggle',
						'name' => 'breadcrumb',
						'label' => __('Enable Page Banner', BUNCH_NAME),
						'description' => __('Enable / disable Page Banner in header for KC template', BUNCH_NAME),
					),
					array(
						'type' => 'radioimage',
						'name' => 'footer_style',
						'label' => __( 'Choose Footer Style', BUNCH_NAME ),
						'item_max_height' => '300',
						'item_max_width' => '400',
						'items' => array(
							array(
								'value' => 'footer_v1',
								'label' => __( 'Footer Style One', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/footer/footer1.png' 
							),
							array(
								'value' => 'footer_v2',
								'label' => __( 'Footer Style Two', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/footer/footer2.png' 
							),
							array(
								'value' => 'footer_v3',
								'label' => __( 'Footer Style Three', BUNCH_NAME ),
								'img' => get_template_directory_uri() . '/images/vafpress/footer/footer3.png' 
							),
						),
						'default' => 'footer_v1'
					),
				),
);
/*$options[] =  array(
	'id'          => _WSH()->set_meta_key('post'),
	'types'       => array('post'),
	'title'       => __('Post Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(		
					array(
					'type' => 'select',
					'name' => 'arrow_view',
					'label' => __('Arrow Layout for "Top Blog Posts" shortcode', BUNCH_NAME),
					'default' => 'img_left',
					'items' => array(
									array(
										'value' => 'img_left',
										'label' => __('Image Left', BUNCH_NAME),
									),
									array(
										'value' => 'img_right',
										'label' => __('Image Right', BUNCH_NAME),
									),
									array(
										'value' => 'img_top',
										'label' => __('Image Top', BUNCH_NAME),
									),
								),
					),
					array(
						'type' => 'textarea',
						'name' => 'description',
						'label' => __('Post Description', BUNCH_NAME),
						'default' => '',
						'description' => __('Enter the post description for detail page.', BUNCH_NAME)
					),
					array(
						'type' => 'textarea',
						'name' => 'video',
						'label' => __('Video Embed Code', BUNCH_NAME),
						'default' => '',
						'description' => __('If post format is video then this embed code will be used in content', BUNCH_NAME)
					),
					array(
						'type' => 'textarea',
						'name' => 'audio',
						'label' => __('Audio Embed Code', BUNCH_NAME),
						'default' => '',
						'description' => __('If post format is AUDIO then this embed code will be used in content', BUNCH_NAME)
					),
					array(
						'type' => 'textarea',
						'name' => 'quote',
						'label' => __('Quote', BUNCH_NAME),
						'default' => '',
						'description' => __('If post format is quote then the content in this textarea will be displayed', BUNCH_NAME)
					),
							
					
			),
);*/
/* Page options */
/** Slides Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_slide'),
	'types'       => array('bunch_slide'),
	'title'       => __('Slides Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_slide_text',
					'title'     => __('Slide Content', BUNCH_NAME),
					'fields'    => array(
						array(
							'type' => 'textarea',
							'name' => 'slide_text',
							'label' => __('Slide Text', BUNCH_NAME),
							'default' => '',
						),
					),
				),
	),
);
/** Services Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_services'),
	'types'       => array( 'bunch_services' ),
	'title'       => __('Services Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
				array(
					'type' => 'fontawesome',
					'name' => 'fontawesome',
					'label' => __('Service Icon', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('Read more link', BUNCH_NAME),
					'default' => '#',
				),
			),
);
/** FAQs Options
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_faqs'),
	'types'       => array('bunch_faqs'),
	'title'       => __('FAQs Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('Read more link', BUNCH_NAME),
					'default' => '#',
				),
	),
);*/
/** Gallery Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_gallery'),
	'types'       => array('bunch_gallery'),
	'title'       => __('Gallery Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				
				
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('External Link', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'select',
					'name' => 'dimension',
					'label' => __('Image Size adjustment for shortcode', BUNCH_NAME),
					'default' => 'normal_width',
					'items' => array(
									array(
										'value' => 'normal_width',
										'label' => __('Normal Width', BUNCH_NAME),
									),
									array(
										'value' => 'extra_width',
										'label' => __('Extra Width', BUNCH_NAME),
									),
									array(
										'value' => 'extra_height',
										'label' => __('Extra Height', BUNCH_NAME),
									),
									array(
										'value' => 'full_width',
										'label' => __('Full Width', BUNCH_NAME),
									),
									
								),
					),
	),
);
/** Team Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_team'),
	'types'       => array('bunch_team'),
	'title'       => __('Team Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', BUNCH_NAME),
					'default' => '',
				),
				/*array(
					'type' => 'textbox',
					'name' => 'team_link',
					'label' => __('Team Link', BUNCH_NAME),
					'default' => '#',
				),*/
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_team_social',
					'title'     => __('Social Profile', BUNCH_NAME),
					'fields'    => array(
						array(
							'type' => 'fontawesome',
							'name' => 'social_icon',
							'label' => __('Social Icon', BUNCH_NAME),
							'default' => '',
						),
						array(
							'type' => 'textbox',
							'name' => 'social_link',
							'label' => __('Social Link', BUNCH_NAME),
							'default' => '#',
						),
					),
				),
	),
);
/** Testimonial Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_testimonials'),
	'types'       => array('bunch_testimonials'),
	'title'       => __('Testimonials Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', BUNCH_NAME),
					'default' => 'Consultant',
				),
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('External Link', BUNCH_NAME),
					'default' => '#',
				),
	),
);
/**
* EOF
*/
return $options;