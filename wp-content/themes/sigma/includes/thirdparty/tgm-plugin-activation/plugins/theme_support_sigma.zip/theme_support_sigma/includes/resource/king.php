<?php
/**
 * Kingcomposer array
 *
 * @package Student WP
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}
$rvslider = array(
				'type'			=> 'dropdown',
				'label'			=> esc_html__('Choose Slider', BUNCH_NAME ),
				'name'			=> 'slider_slug',
				'options'		=> bunch_get_rev_slider( 0 ),
				'description'	=> esc_html__('Choose Slider', BUNCH_NAME ),
			);
$lm_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Learn More Title', BUNCH_NAME ),
				"name"			=>	"lm_title",
				"description"	=>	esc_html__('Enter section Learn More title.', BUNCH_NAME ),
				'value'			=>	esc_html__('Learn More', BUNCH_NAME ),
			);
$lm_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Learn More Link', BUNCH_NAME ),
				"name"			=>	"lm_link",
				"description"	=>	esc_html__('Enter section Learn More Link.', BUNCH_NAME ),
				'value'			=>	'#',
			);
$cu_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Contact Us Title', BUNCH_NAME ),
				"name"			=>	"cu_title",
				"description"	=>	esc_html__('Enter section Contact Us title.', BUNCH_NAME ),
				'value'			=>	esc_html__('Contact Us', BUNCH_NAME ),
			);
$cu_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Contact Us Link', BUNCH_NAME ),
				"name"			=>	"cu_link",
				"description"	=>	esc_html__('Enter section Contact Us Link.', BUNCH_NAME ),
				'value'			=>	'#',
			);
$text_limit = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Text Limit', BUNCH_NAME ),
				"name"			=>	"text_limit",
				"description"	=>	esc_html__('Enter text limit of posts to Show.', BUNCH_NAME ),
			);
$number = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Number', BUNCH_NAME ),
				"name"			=>	"num",
				"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME ),
			);
$orderby = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order By", BUNCH_NAME),
				"name"			=>	"sort",
				'options'		=>	array(
										'date' => esc_html__('Date', BUNCH_NAME),
										'title' => esc_html__('Title', BUNCH_NAME),
										'name' => esc_html__('Name', BUNCH_NAME),
										'author' => esc_html__('Author', BUNCH_NAME),
										'comment_count' => esc_html__('Comment Count', BUNCH_NAME),
										'random' => esc_html__('Random', BUNCH_NAME)
									),
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME),
			);
$order = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order", BUNCH_NAME),
				"name"			=>	"order",
				'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$name = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Name', BUNCH_NAME ),
				"name"			=>	"name",
				"description"	=>	esc_html__('Enter section name.', BUNCH_NAME )
			);
$designation = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Designation', BUNCH_NAME ),
				"name"			=>	"designation",
				"description"	=>	esc_html__('Enter the designation.', BUNCH_NAME )
			);
$title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"title",
				"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
			);
$text_list = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text List', BUNCH_NAME ),
				"name"			=>	"text_list",
				"description"	=>	esc_html__('Enter listing to show.', BUNCH_NAME )
			);
$subtitle = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Sub-Title', BUNCH_NAME ),
				"name"			=>	"subtitle",
				"description"	=>	esc_html__('Enter section subtitle.', BUNCH_NAME )
			);
$text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"text",
				"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
			);
$editor  = array(
				"type"			=>	"editor",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"editor",
				"description"	=>	esc_html__('Enter title to show.', BUNCH_NAME )
			);
$email = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Email', BUNCH_NAME ),
				"name"			=>	"email",
				"description"	=>	esc_html__('Enter email.', BUNCH_NAME )
			);
$phone = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Phone', BUNCH_NAME ),
				"name"			=>	"phone",
				"description"	=>	esc_html__('Enter phone.', BUNCH_NAME )
			);
$address = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Address', BUNCH_NAME ),
				"name"			=>	"address",
				"description"	=>	esc_html__('Enter address.', BUNCH_NAME )
			);
$website = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Website', BUNCH_NAME ),
				"name"			=>	"website",
				"description"	=>	esc_html__('Enter website.', BUNCH_NAME )
			);
$working_hours = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Working Hours', BUNCH_NAME ),
				"name"			=>	"working_hours",
				"description"	=>	esc_html__('Enter Working Hours.', BUNCH_NAME )
			);
$contact_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Contact Us Title', BUNCH_NAME ),
				"name"			=>	"contact_title",
				"description"	=>	esc_html__('Enter contact us title.', BUNCH_NAME )
			);
$contact_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Us Description', BUNCH_NAME ),
				"name"			=>	"contact_text",
				"description"	=>	esc_html__('Enter contact us description.', BUNCH_NAME )
			);
$contact_shortcode = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Us Shortcode', BUNCH_NAME ),
				"name"			=>	"contact_shortcode",
				"description"	=>	esc_html__('Enter contact us shortcode to show.', BUNCH_NAME )
			);
$latitude = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Latitude', BUNCH_NAME ),
				"name"			=>	"latitude",
				"description"	=>	esc_html__('Enter latitude.', BUNCH_NAME )
			);
$longitude = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Longitude', BUNCH_NAME ),
				"name"			=>	"longitude",
				"description"	=>	esc_html__('Enter longitude.', BUNCH_NAME )
			);
$zoom = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Map Zoom', BUNCH_NAME ),
				"name"			=>	"zoom",
				"description"	=>	esc_html__('Enter map zoom.', BUNCH_NAME ),
				'value'			=>	'12',
			);
$pointer = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Map Pointer', BUNCH_NAME ),
				"name"			=>	"pointer",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose map pointer.', BUNCH_NAME ),
				'value'			=>	get_template_directory_uri().'/images/icons/map-marker.png',
			);
$btn_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Title', BUNCH_NAME ),
				"name"			=>	"btn_title",
				"description"	=>	esc_html__('Enter section Button title.', BUNCH_NAME )
			);
$btn_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Link', BUNCH_NAME ),
				"name"			=>	"btn_link",
				"description"	=>	esc_html__('Enter section Button Link.', BUNCH_NAME ),
				'value'			=>	'#',
			);
$img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Image', BUNCH_NAME ),
				"name"			=>	"img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
			);
$slide_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Slide Image', BUNCH_NAME ),
				"name"			=>	"slide_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Slide image.', BUNCH_NAME )
			);
$bg_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
				"name"			=>	"bg_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Background image.', BUNCH_NAME )
			);			
$multi_img = array(
				"type"			=>	"attach_images",
				"label"			=>	esc_html__('Multi Images', BUNCH_NAME ),
				"name"			=>	"multi_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Uplod multi images.', BUNCH_NAME )
			);
$signature = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Signature', BUNCH_NAME ),
				"name"			=>	"signature",
				"description"	=>	esc_html__('Choose Signature.', BUNCH_NAME )
			);
$video_url = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Video URL', BUNCH_NAME ),
				"name"			=>	"video_url",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Enter video url.', BUNCH_NAME )
			);
$video_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Video Image', BUNCH_NAME ),
				"name"			=>	"video_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose video image.', BUNCH_NAME )
			);
$video_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Video Title', BUNCH_NAME ),
				"name"			=>	"video_title",
				"description"	=>	esc_html__('Enter video title.', BUNCH_NAME )
			);
$video_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Video Description', BUNCH_NAME ),
				"name"			=>	"video_text",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Enter video Description.', BUNCH_NAME )
			);
$icon = array(
				'type'			=>	'icon_picker',
				'label'			=>	esc_html__('Icon', BUNCH_NAME ),
				'name'			=>	'icon',
				'description'	=>	esc_html__('Enter your icon', BUNCH_NAME )
			);
$url = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('URL', BUNCH_NAME ),
				'name'			=>	'url',
				'description'	=>	esc_html__('Enter url', BUNCH_NAME ),
				'value'			=>	'#',
			);
$ff_start = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Counter Start', BUNCH_NAME ),
				'name'			=>	'ff_start',
				'description'	=>	esc_html__('Enter Counter Start', BUNCH_NAME ),
				'value'			=>	'0',
			);
$ff_stop = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Counter Stop', BUNCH_NAME ),
				'name'			=>	'ff_stop',
				'description'	=>	esc_html__('Enter Counter Stop', BUNCH_NAME )
			);
$ff_sign = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Counter Sign', BUNCH_NAME ),
				'name'			=>	'ff_sign',
				'description'	=>	esc_html__('Enter Counter Sign', BUNCH_NAME ),
			);
$newsletter_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Newsletter Title', BUNCH_NAME ),
				"name"			=>	"newsletter_title",
				"description"	=>	esc_html__('Enter Newsletter Title.', BUNCH_NAME ),
			);
$newsletter_id = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Newsletter ID', BUNCH_NAME ),
				"name"			=>	"newsletter_id",
				"description"	=>	esc_html__('Choose Newsletter ID.', BUNCH_NAME ),
				'value'			=>	'#',
			);
$newsletter_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Newsletter Text', BUNCH_NAME ),
				"name"			=>	"newsletter_text",
				"description"	=>	esc_html__('Choose Newsletter Text.', BUNCH_NAME ),
			);
$date = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Date', BUNCH_NAME ),
				'name'			=>	'date',
				'description'	=>	esc_html__('Enter Date', BUNCH_NAME )
			);
$sidebar = array(
				'type'			=> 'dropdown',
				'label'			=> esc_html__( 'Choose Sidebar', BUNCH_NAME ),
				'name'			=> 'sidebar_slug',
				'options'		=> sigma_bunch_get_sidebars(),
				'description'	=> esc_html__( 'Choose Sidebar.', BUNCH_NAME ),
			);
$cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__('Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array('taxonomy' =>	'category'), true),
				"description"	=>	__('Choose Category.', BUNCH_NAME)
			);
$services_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'services_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$projects_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'gallery_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$team_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'team_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$testimonials_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'testimonials_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$faqs_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'faqs_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$blog_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);			
$exclude_cats = array(
			   "type"			=>	"textfield",
			   "label"			=>	__('Excluded Categories ID', BUNCH_NAME ),
			   "name"			=>	"exclude_cats",
			   "description"	=>	__('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
			);
$options = array();

//Revslider
$options['bunch_revslider'] = array(
					'name' => esc_html__('Revslider', BUNCH_NAME),
					'base' => 'bunch_revslider',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Revolution slider.', BUNCH_NAME),
					'params' => array(
						$rvslider,
					),
			);
//About Us 1
$options['bunch_about_us_1'] = array(
					'name' => esc_html__('About Us V1', BUNCH_NAME),
					'base' => 'bunch_about_us_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show About Us 1.', BUNCH_NAME),
					'params' => array(
						$title,
						$subtitle,
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Customize Title', BUNCH_NAME ),
							"name"			=>	"customize_title",
							"description"	=>	esc_html__('Enter section Customize Title.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Customize Text', BUNCH_NAME ),
							"name"			=>	"customize_text",
							"description"	=>	esc_html__('Enter section Customize Text.', BUNCH_NAME )
						),
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Modern Design Title', BUNCH_NAME ),
							"name"			=>	"md_title",
							"description"	=>	esc_html__('Enter section Modern Design Title.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Skills Text', BUNCH_NAME ),
							"name"			=>	"md_text",
							"description"	=>	esc_html__('Enter section Modern Design Text.', BUNCH_NAME )
						),
						array(
							'type' => 'group',
							'label' => esc_html__( 'About Skills', BUNCH_NAME ),
							'name' => 'about_skills',
							'description' => esc_html__( 'Enter About Skills.', BUNCH_NAME ),
							'params' => array(
								$title,
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Skills', BUNCH_NAME ),
									"name"			=>	"skills",
									"description"	=>	esc_html__('Enter skills between 1 to 100.', BUNCH_NAME )
								),
							),
						),
					),
			);
//Our Skills
$options['bunch_our_skills'] = array(
					'name' => esc_html__('Our Skills', BUNCH_NAME),
					'base' => 'bunch_our_skills',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Skills.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$subtitle,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Our Skills', BUNCH_NAME ),
							'name' => 'our_skills',
							'description' => esc_html__( 'Enter Our Skills.', BUNCH_NAME ),
							'params' => array(
								$title,
								$subtitle,
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Skills', BUNCH_NAME ),
									"name"			=>	"skills",
									"description"	=>	esc_html__('Enter skills between 1 to 100.', BUNCH_NAME )
								),
							),
						),
					),
			);
//Our Team 1
$options['bunch_our_team_1'] = array(
					'name' => esc_html__('Our Team V1', BUNCH_NAME),
					'base' => 'bunch_our_team_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Team 1.', BUNCH_NAME),
					'params' => array(
						$title,
						$subtitle,
						$text_limit,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//Our Services 1
$options['bunch_our_services_1'] = array(
					'name' => esc_html__('Our Services V1', BUNCH_NAME),
					'base' => 'bunch_our_services_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Services 1.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$subtitle,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Price Plan 1
$options['bunch_price_plan_1'] = array(
					'name' => esc_html__('Price Plan V1', BUNCH_NAME),
					'base' => 'bunch_price_plan_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Price Plan 1.', BUNCH_NAME),
					'params' => array(
						$title,
						$subtitle,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Price Plan', BUNCH_NAME ),
							'name' => 'price_plan',
							'description' => esc_html__( 'Enter Price Plan Details', BUNCH_NAME ),
							'params' => array(
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Plan Name', BUNCH_NAME ),
									"name"			=>	"plan_name",
									"description"	=>	esc_html__('Enter Plan Name.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Currency Sign', BUNCH_NAME ),
									"name"			=>	"currency_sign",
									"description"	=>	esc_html__('Enter Currency Sign.', BUNCH_NAME ),
									"value"			=>	esc_html__('$', BUNCH_NAME ),
								),
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Amount', BUNCH_NAME ),
									"name"			=>	"amount",
									"description"	=>	esc_html__('Enter Amount.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Package Plan', BUNCH_NAME ),
									"name"			=>	"package_plan",
									"description"	=>	esc_html__('Enter Package Plan.', BUNCH_NAME ),
									"value"			=>	esc_html__('monthly', BUNCH_NAME ),
								),
								$text,
								$btn_title,
								$btn_link,
							),
						),
					),
			);
			
//Our Work 1
$options['bunch_our_work_1'] = array(
					'name' => esc_html__('Our Work V1', BUNCH_NAME),
					'base' => 'bunch_our_work_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Work.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$projects_cat,
						$orderby,
						$order,
					),
			);	
			
//Our Blog 1
$options['bunch_latest_news_1'] = array(
					'name' => esc_html__('Latest News V1', BUNCH_NAME),
					'base' => 'bunch_latest_news_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Latest News V1.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$blog_cat,
						$orderby,
						$order,
					),
			);	
			
//Contact Info Home 1
$options['bunch_contact_us_1'] = array(
					'name' => esc_html__('Contact Info V1', BUNCH_NAME),
					'base' => 'bunch_contact_us_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Contact Information.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Contact Information', BUNCH_NAME ),
							'name' => 'contact',
							'description' => esc_html__( 'Enter Contact Information.', BUNCH_NAME ),
							'params' => array(
								$icon,
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Title', BUNCH_NAME ),
									"name"			=>	"c_title",
									"description"	=>	esc_html__('Enter Title here.', BUNCH_NAME )
								),
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Text', BUNCH_NAME ),
									"name"			=>	"c_text",
									"description"	=>	esc_html__('Enter Text.', BUNCH_NAME )
								),
							),
						),
					),
			);	
			
//Map and Contact Home 1
$options['bunch_map_contact_1'] = array(
					'name' => esc_html__('Map and Contact V1', BUNCH_NAME),
					'base' => 'bunch_map_contact_1',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Map and Contact.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'Map', BUNCH_NAME ) => array(
							$zoom,
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Map Height', BUNCH_NAME ),
								"name"			=>	"height",
								"description"	=>	esc_html__('Enter Map Height here.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Map Address', BUNCH_NAME ),
								"name"			=>	"address",
								"description"	=>	esc_html__('Enter Map Address here.', BUNCH_NAME )
							),
						),
						//Tabs Start
						esc_html__( 'Contact Form', BUNCH_NAME ) => array(
							$contact_shortcode,
						),
					),
			);				
			
/***********************
	Home 2 Shortcodes
************************/			
			
//Main Slider
$options['bunch_main_slider'] = array(
					'name' => esc_html__('Main Slider', BUNCH_NAME),
					'base' => 'bunch_main_slider',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Main Slider.', BUNCH_NAME),
					'params' => array(
						array(
							'type' => 'group',
							'label' => esc_html__( 'Slider', BUNCH_NAME ),
							'name' => 'main_slider',
							'description' => esc_html__( 'Enter The Slide.', BUNCH_NAME ),
							'params' => array(
								$title,
								$text,
								$btn_link,
								$btn_title,
								$slide_img,
							),
						),
					),
			);	
			
//Our Services 2
$options['bunch_our_services_2'] = array(
					'name' => esc_html__('Our Services V2', BUNCH_NAME),
					'base' => 'bunch_our_services_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Services 2.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
						array(
							"type"			=>	"checkbox",
							"label"			=>	esc_html__('Style Two', BUNCH_NAME ),
							"name"			=>	"style_two",
							'options' => array(
								'option_1' => 'Style Two',
							),
							"description"	=>	esc_html__('Choose whether you want to show the services style 2 with Background.', BUNCH_NAME  )
						),
					),
			);	
			
//Our Work 2
$options['bunch_our_work_2'] = array(
					'name' => esc_html__('Our Work V2', BUNCH_NAME),
					'base' => 'bunch_our_work_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Work V2.', BUNCH_NAME),
					'params' => array(
						$number,
						$projects_cat,
						$orderby,
						$order,
					),
			);	
			
//About Us 2
$options['bunch_about_us_2'] = array(
					'name' => esc_html__('About Us V2', BUNCH_NAME),
					'base' => 'bunch_about_us_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show About Us 2.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$img,
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Customize Title', BUNCH_NAME ),
							"name"			=>	"customize_title",
							"description"	=>	esc_html__('Enter section Customize Title.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Customize Text', BUNCH_NAME ),
							"name"			=>	"customize_text",
							"description"	=>	esc_html__('Enter section Customize Text.', BUNCH_NAME )
						),
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Modern Design Title', BUNCH_NAME ),
							"name"			=>	"md_title",
							"description"	=>	esc_html__('Enter section Modern Design Title.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Skills Text', BUNCH_NAME ),
							"name"			=>	"md_text",
							"description"	=>	esc_html__('Enter section Modern Design Text.', BUNCH_NAME )
						),
					),
			);	
			
//Our Skills
$options['bunch_funfact'] = array(
					'name' => esc_html__('Fun Facts', BUNCH_NAME),
					'base' => 'bunch_funfact',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Fun Facts.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Our Skills', BUNCH_NAME ),
							'name' => 'our_skills',
							'description' => esc_html__( 'Enter Our Skills.', BUNCH_NAME ),
							'params' => array(
								$title,
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Data Count', BUNCH_NAME ),
									"name"			=>	"data_value",
									"description"	=>	esc_html__('Enter Data Count.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Symbol', BUNCH_NAME ),
									"name"			=>	"data_symbol",
									"description"	=>	esc_html__('Enter The Symbol to Show.', BUNCH_NAME )
								),
							),
						),
					),
			);
			
//Our Blog 1
$options['bunch_latest_news_2'] = array(
					'name' => esc_html__('Latest News V2', BUNCH_NAME),
					'base' => 'bunch_latest_news_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Latest News V2.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$blog_cat,
						$orderby,
						$order,
					),
			);	
			
//Our Sponsors
$options['bunch_clients'] = array(
					'name' => esc_html__('Sponsors', BUNCH_NAME),
					'base' => 'bunch_clients',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Sponsors.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Sponsors', BUNCH_NAME ),
							'name' => 'clients',
							'description' => esc_html__( 'Enter Our Sponsors.', BUNCH_NAME ),
							'params' => array(
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Image', BUNCH_NAME ),
									"name"			=>	"client_img",
									"description"	=>	esc_html__('Enter Image.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Link', BUNCH_NAME ),
									"name"			=>	"link",
									"description"	=>	esc_html__('Enter Image Link here.', BUNCH_NAME )
								),
							),
						),
					),
			);	
			
//Map and Contact Home 2
$options['bunch_map_contact_2'] = array(
					'name' => esc_html__('Map and Contact V2', BUNCH_NAME),
					'base' => 'bunch_map_contact_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Map and Contact.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
						),
						//Tabs Start
						esc_html__( 'Map', BUNCH_NAME ) => array(
							$zoom,
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Map Height', BUNCH_NAME ),
								"name"			=>	"height",
								"description"	=>	esc_html__('Enter Map Height here.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Mark Title', BUNCH_NAME ),
								"name"			=>	"map_title",
								"description"	=>	esc_html__('Enter Mark Title here.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Map Address', BUNCH_NAME ),
								"name"			=>	"address",
								"description"	=>	esc_html__('Enter Map Address here.', BUNCH_NAME )
							),
						),
						//Tabs Start
						esc_html__( 'Contact Form', BUNCH_NAME ) => array(
							$contact_shortcode,
						),
					),
			);	
			
/***********************
	Home 3 Shortcodes
************************/			
			
//Main Slider
$options['bunch_main_slider_v2'] = array(
					'name' => esc_html__('Main Slider V2', BUNCH_NAME),
					'base' => 'bunch_main_slider_v2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Main Slider V2.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$btn_link,
						$btn_title,
					),
			);
			
//Feature Services
$options['bunch_feature_services']	=	array(
					'name' => esc_html__('Feature Services', BUNCH_NAME),
					'base' => 'bunch_feature_services',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Feature Services.', BUNCH_NAME),
					'tab_icons' => array(
						'General' => 'et-tools',
						'Opening Hours' => 'et-adjustments',
						'Memory Content' => 'et-lightbulb',
					),
					'params' => array(
						
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							
							$title,
							$text,
						
						),
						
						//Tabs Start
						esc_html__( 'Tab', BUNCH_NAME ) => array(

							//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Tab', BUNCH_NAME ),
								 'name' => 'tab',
								 'description' => esc_html__( 'Enter the Tab Data.', BUNCH_NAME ),
								 'params' => array(
										
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 't_title',
											 'description' => esc_html__( 'Enter Title.', BUNCH_NAME ),
										),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Sub Title', BUNCH_NAME ),
											 'name' => 'title1',
											 'description' => esc_html__( 'Enter Sub Title.', BUNCH_NAME ),
										),
										array(
											 'type' => 'textarea',
											 'label' => esc_html__( 'Text', BUNCH_NAME ),
											 'name' => 't_text',
											 'description' => esc_html__( 'Enter Text.', BUNCH_NAME ),
										),
										array(
											'type' => 'attach_image_url',
											'label' => __('Image',  BUNCH_NAME),
											'name' => 'img',
											'admin_label' => false,
											'description' => __('Choose image.',  BUNCH_NAME)
										),
										
								 ),
							),//Group End
				
					    ),//Tabs End
						
					),
			);	
			
//Our Services 3
$options['bunch_our_services_3'] = array(
					'name' => esc_html__('Our Services V3', BUNCH_NAME),
					'base' => 'bunch_our_services_3',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Services 3.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
						array(
							"type"			=>	"checkbox",
							"label"			=>	esc_html__('Style Two', BUNCH_NAME ),
							"name"			=>	"style_two",
							'options' => array(
								'option_1' => 'Style Two',
							),
							"description"	=>	esc_html__('Choose whether you want to show Or Hide The Services Style 2 without Background.', BUNCH_NAME  )
						),
					),
			);	
			
//Feature Services
$options['bunch_about_us_3']	=	array(
					'name' => esc_html__('About Us V3', BUNCH_NAME),
					'base' => 'bunch_about_us_3',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us V3.', BUNCH_NAME),
					'tab_icons' => array(
						'General' => 'et-tools',
						'Opening Hours' => 'et-adjustments',
						'Memory Content' => 'et-lightbulb',
					),
					'params' => array(
						
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							
							$title,
							$text,
							$img,
						
						),
						
						//Tabs Start
						esc_html__( 'Tab', BUNCH_NAME ) => array(

							//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Accordian', BUNCH_NAME ),
								 'name' => 'accordian',
								 'description' => esc_html__( 'Enter the Accordian Data.', BUNCH_NAME ),
								 'params' => array(
										
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 'a_title',
											 'description' => esc_html__( 'Enter Title.', BUNCH_NAME ),
										),
										array(
											 'type' => 'textarea',
											 'label' => esc_html__( 'Text', BUNCH_NAME ),
											 'name' => 'a_text',
											 'description' => esc_html__( 'Enter Text.', BUNCH_NAME ),
										),
										
								 ),
							),//Group End
				
					    ),//Tabs End
						
					),
			);	
			
//Our Team 1
$options['bunch_our_team_2'] = array(
					'name' => esc_html__('Our Team V2', BUNCH_NAME),
					'base' => 'bunch_our_team_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Team 2.', BUNCH_NAME),
					'params' => array(
						$title,
						$subtitle,
						$text,
						$text_limit,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);	
			
//Our Work 3 Filtration
$options['bunch_our_work_3'] = array(
					'name' => esc_html__('Our Work V3', BUNCH_NAME),
					'base' => 'bunch_our_work_3',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Work Filtration.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$exclude_cats,
						$orderby,
						$order,
						$btn_title,
						$btn_link,
					),
			);	
			
//Our Work 3 Filtration
$options['bunch_testimonial'] = array(
					'name' => esc_html__('Testimonial', BUNCH_NAME),
					'base' => 'bunch_testimonial',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Testimonial.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$text_limit,
						$number,
						$testimonials_cat,
						$orderby,
						$order,
					),
			);
			
//Map and Contact Home 1
$options['bunch_map_contact_3'] = array(
					'name' => esc_html__('Map and Contact V3', BUNCH_NAME),
					'base' => 'bunch_map_contact_3',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Map and Contact Home 3.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
							$bg_img,
							array(
								"type"			=>	"checkbox",
								"label"			=>	esc_html__('Style Two', BUNCH_NAME ),
								"name"			=>	"style_two",
								'options' => array(
									'option_1' => 'Style Two',
								),
								"description"	=>	esc_html__('Choose whether you want to show the Map style 2 with Background.', BUNCH_NAME  )
							),
						),
						//Tabs Start
						esc_html__( 'Map', BUNCH_NAME ) => array(
							$zoom,
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Map Height', BUNCH_NAME ),
								"name"			=>	"height",
								"description"	=>	esc_html__('Enter Map Height here.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Mark Title', BUNCH_NAME ),
								"name"			=>	"map_title",
								"description"	=>	esc_html__('Enter Mark Title here.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Map Address', BUNCH_NAME ),
								"name"			=>	"map_address",
								"description"	=>	esc_html__('Enter Map Address here.', BUNCH_NAME )
							),
						),
						//Tabs Start
						esc_html__( 'Contact Form', BUNCH_NAME ) => array(
							$contact_title,
							$contact_shortcode,
						),
						//Tabs Start
						esc_html__( 'Contact Information', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title1",
								"description"	=>	esc_html__('Enter Title here.', BUNCH_NAME )
							),
							$contact_text,
							$address,
							$phone,
							$email,
						),
					),
			);	
			
/***********************
	Home 4 Shortcodes
************************/			
			
//Main Slider
$options['bunch_video_slider'] = array(
					'name' => esc_html__('Video Slider', BUNCH_NAME),
					'base' => 'bunch_video_slider',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Video Slider.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$video_url,
						$title,
						$text,
						$btn_link,
						$btn_title,
					),
			);
			
//Our Services 3
$options['bunch_our_services_4'] = array(
					'name' => esc_html__('Our Services V4', BUNCH_NAME),
					'base' => 'bunch_our_services_4',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Services 4.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);	
			
//Our Work 4 Carasoul
$options['bunch_our_work_4'] = array(
					'name' => esc_html__('Work Carasoul', BUNCH_NAME),
					'base' => 'bunch_our_work_4',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Work Carasoul.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$projects_cat,
						$orderby,
						$order,
					),
			);	
			
//Our Work 4 Carasoul
$options['bunch_about_us_4'] = array(
					'name' => esc_html__('About Us V4', BUNCH_NAME),
					'base' => 'bunch_about_us_4',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us V4.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$img,
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Title', BUNCH_NAME ),
							"name"			=>	"title1",
							"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Text', BUNCH_NAME ),
							"name"			=>	"text1",
							"description"	=>	esc_html__('Enter Section Text.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Features List', BUNCH_NAME ),
							"name"			=>	"feature_str",
							"description"	=>	esc_html__('Enter Amount.', BUNCH_NAME )
						),
					),
			);	
			
//Price Plan 1
$options['bunch_price_plan_2'] = array(
					'name' => esc_html__('Price Plan V2', BUNCH_NAME),
					'base' => 'bunch_price_plan_2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Price Plan V2.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Price Plan', BUNCH_NAME ),
							'name' => 'price_plan',
							'description' => esc_html__( 'Enter Price Plan Details', BUNCH_NAME ),
							'params' => array(
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Plan Name', BUNCH_NAME ),
									"name"			=>	"plan_name",
									"description"	=>	esc_html__('Enter Plan Name.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Currency Sign', BUNCH_NAME ),
									"name"			=>	"currency_sign",
									"description"	=>	esc_html__('Enter Currency Sign.', BUNCH_NAME ),
									"value"			=>	esc_html__('$', BUNCH_NAME ),
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Amount', BUNCH_NAME ),
									"name"			=>	"amount",
									"description"	=>	esc_html__('Enter Amount.', BUNCH_NAME )
								),
								$text,
								$btn_title,
								$btn_link,
							),
						),
					),
			);	
			
//Map and Contact Home 1
$options['bunch_map_contact_4'] = array(
					'name' => esc_html__('Map and Contact V4', BUNCH_NAME),
					'base' => 'bunch_map_contact_4',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Map and Contact Home 4.', BUNCH_NAME),
					'params' => array(
						
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
						),
						
						//Tabs Start
						esc_html__( 'Map', BUNCH_NAME ) => array(
							$zoom,
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Map Height', BUNCH_NAME ),
								"name"			=>	"height",
								"description"	=>	esc_html__('Enter Map Height here.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Map Address', BUNCH_NAME ),
								"name"			=>	"map_address",
								"description"	=>	esc_html__('Enter Map Address here.', BUNCH_NAME )
							),
						),
						//Tabs Start
						esc_html__( 'Contact Form', BUNCH_NAME ) => array(
							$contact_shortcode,
						),
					),
			);
			
//Map and Contact Home 1
$options['bunch_newsletter'] = array(
					'name' => esc_html__('Our Newsletter', BUNCH_NAME),
					'base' => 'bunch_newsletter',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Newsletter.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$contact_shortcode,
					),
			);	
			
/***********************
	Home 5 Shortcodes
************************/				
			
//Main Slider V3
$options['bunch_main_slider_v3'] = array(
					'name' => esc_html__('Main Banner V1', BUNCH_NAME),
					'base' => 'bunch_main_slider_v3',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Main Banner V1.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$btn_link,
						$btn_title,
					),
			);	
			
//Video Perallex
$options['bunch_video_perallex'] = array(
					'name' => esc_html__('Video Perallex', BUNCH_NAME),
					'base' => 'bunch_video_perallex',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Video Perallex.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$video_url,
						$title,
						$text,
					),
			);	
			
//Our Work 5
$options['bunch_our_work_5'] = array(
					'name' => esc_html__('Our Work V5', BUNCH_NAME),
					'base' => 'bunch_our_work_5',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Work V5.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$projects_cat,
						$orderby,
						$order,
					),
			);
			
//Features Slider
$options['bunch_feature_slider'] = array(
					'name' => esc_html__('Feature Slider', BUNCH_NAME),
					'base' => 'bunch_feature_slider',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Feature Slider.', BUNCH_NAME),
					'params' => array(
						$title,
						$subtitle,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Feature Slider', BUNCH_NAME ),
							'name' => 'slider',
							'description' => esc_html__( 'Feature Slider', BUNCH_NAME ),
							'params' => array(
								$img,
							),
						),
						
					),
			);	
			
//Testimonial V2
$options['bunch_testimonial_v2'] = array(
					'name' => esc_html__('Testimonial V2', BUNCH_NAME),
					'base' => 'bunch_testimonial_v2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Testimonial V2.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$text_limit,
						$number,
						$testimonials_cat,
						$orderby,
						$order,
					),
			);	
			
//Our Sponsors V2
$options['bunch_clients_v2'] = array(
					'name' => esc_html__('Sponsors V2', BUNCH_NAME),
					'base' => 'bunch_clients_v2',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Sponsors V2.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Sponsors', BUNCH_NAME ),
							'name' => 'clients',
							'description' => esc_html__( 'Enter Our Sponsors.', BUNCH_NAME ),
							'params' => array(
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Image', BUNCH_NAME ),
									"name"			=>	"client_img",
									"description"	=>	esc_html__('Enter Image.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Link', BUNCH_NAME ),
									"name"			=>	"link",
									"description"	=>	esc_html__('Enter Image Link here.', BUNCH_NAME )
								),
							),
						),
					),
			);	
			
/***********************
	Home 6 Shortcodes
************************/				
			
//Main Slider V6
$options['bunch_main_slider_v4'] = array(
					'name' => esc_html__('Main Banner V2', BUNCH_NAME),
					'base' => 'bunch_main_slider_v4',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Main Banner V2.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$btn_link,
						$btn_title,
					),
			);	
			
//Feature Services
$options['bunch_about_us_5']	=	array(
					'name' => esc_html__('About Us V5', BUNCH_NAME),
					'base' => 'bunch_about_us_5',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us V5.', BUNCH_NAME),
					'tab_icons' => array(
						'General' => 'et-tools',
						'Opening Hours' => 'et-adjustments',
						'Memory Content' => 'et-lightbulb',
					),
					'params' => array(
						
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
						),
						
						//Tabs Start
						esc_html__( 'Accordian', BUNCH_NAME ) => array(

							//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Accordian', BUNCH_NAME ),
								 'name' => 'accordian',
								 'description' => esc_html__( 'Enter the Accordian Data.', BUNCH_NAME ),
								 'params' => array(
										
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 'a_title',
											 'description' => esc_html__( 'Enter Title.', BUNCH_NAME ),
										),
										array(
											 'type' => 'textarea',
											 'label' => esc_html__( 'Text', BUNCH_NAME ),
											 'name' => 'a_text',
											 'description' => esc_html__( 'Enter Text.', BUNCH_NAME ),
										),
										
								 ),
							),//Group End
				
					    ),//Tabs End
						//Tabs Start
						esc_html__( 'Skills', BUNCH_NAME ) => array(
							array(
								'type' => 'group',
								'label' => esc_html__( 'About Skills', BUNCH_NAME ),
								'name' => 'about_skills',
								'description' => esc_html__( 'Enter About Skills.', BUNCH_NAME ),
								'params' => array(
									$title,
									array(
										"type"			=>	"text",
										"label"			=>	esc_html__('Skills', BUNCH_NAME ),
										"name"			=>	"skills",
										"description"	=>	esc_html__('Enter skills between 1 to 100.', BUNCH_NAME )
									),
								),
							),
						),
						
					),
			);		
			
//Our Work 2
$options['bunch_our_work_6'] = array(
					'name' => esc_html__('Our Work V6', BUNCH_NAME),
					'base' => 'bunch_our_work_6',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Work V6.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$projects_cat,
						$orderby,
						$order,
					),
			);	
			
/****************************
		Portfolio Single
****************************/			
			
//Contact Info Home 1
$options['bunch_single_slider'] = array(
					'name' => esc_html__('Portfolio Single', BUNCH_NAME),
					'base' => 'bunch_single_slider',
					'class' => '',
					'category' => esc_html__('Sigma', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Portfolio Single.', BUNCH_NAME),
					'params' => array(
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
						),
						esc_html__( 'Slider', BUNCH_NAME ) => array(
							array(
								'type' => 'group',
								'label' => esc_html__( 'Slider', BUNCH_NAME ),
								'name' => 'slider',
								'description' => esc_html__( 'Enter Slider.', BUNCH_NAME ),
								'params' => array(
									$slide_img,
								),
							),
						),
						esc_html__( 'Share Details', BUNCH_NAME ) => array(
							array(
								'type' => 'group',
								'label' => esc_html__( 'Share Icons', BUNCH_NAME ),
								'name' => 'share',
								'description' => esc_html__( 'Enter Slider.', BUNCH_NAME ),
								'params' => array(
									$icon,
									array(
										"type"			=>	"text",
										"label"			=>	esc_html__('Link', BUNCH_NAME ),
										"name"			=>	"link",
										"description"	=>	esc_html__('Enter The Link.', BUNCH_NAME )
									),
								),
							),
						),
						esc_html__( 'Project Details', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title1",
								"description"	=>	esc_html__('Enter The Title.', BUNCH_NAME )
							),
							$editor,
						),
					),
			);																																																																																

return $options;
