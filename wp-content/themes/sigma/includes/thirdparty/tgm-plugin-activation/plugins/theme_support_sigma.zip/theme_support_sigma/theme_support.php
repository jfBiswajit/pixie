<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/
Description: This plugin is compatible with this wordpress themes. 
Author: Muhibbur Rashid
Author URI: http://themebunch.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'sigma' );
include_once( 'includes/loader.php' );

function sigma_bunch_widget_init2()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_About_us' ) )register_widget( 'Bunch_About_us' );
	if( class_exists( 'Bunch_Quote' ) )register_widget( 'Bunch_Quote' );
	if( class_exists( 'Bunch_Recent_Post' ) )register_widget( 'Bunch_Recent_Post' );
	if( class_exists( 'Bunch_Contact_Us' ) )register_widget( 'Bunch_Contact_Us' );
	//Service Widget
	if( class_exists( 'Bunch_services' ) )register_widget( 'Bunch_services' );
	if( class_exists( 'Bunch_Brochures' ) )register_widget( 'Bunch_Brochures' );
	if( class_exists( 'Bunch_We_Can_Help' ) )register_widget( 'Bunch_We_Can_Help' );
}
add_action( 'widgets_init', 'sigma_bunch_widget_init2' );